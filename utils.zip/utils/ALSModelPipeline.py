# PySpark ML Recommendation imports
from pyspark.ml.recommendation import ALS, ALSModel

# Evaluation Metrics
from pyspark.mllib.evaluation import RankingMetrics

# Standard SQL Functions
from pyspark.sql import functions as F

# ==========================================
# 2. MODEL PIPELINE CLASS
# ==========================================
class ALSModelPipeline:
    """
    Handles training, evaluation, and inference for the ALS recommendation model.
    """
    
    def __init__(self, spark, config, data_prep=None):
        self.spark = spark
        self.config = config
        self.data_prep = data_prep # Takes the prepared data object
        
        # State variables for our model and predictions
        self.als_model = None
        self.als_raw_50 = None     # Used for Coverage
        self.als_novel_15 = None   # Used for Recall/Precision and Inference

    def _generate_novel_recommendations(self, raw_recs_df, k_novel):
        """Filters watched items from the raw 50 recs to return the top 'k_novel' items."""
        print(f"Filtering raw recommendations down to {k_novel} novel items per user...")
        
        watched_items_df = self.data_prep.indexed_train.groupBy("userIndex").agg(
            F.collect_set("itemIndex").alias("watched_items")
        )
        
        novel_recs_df = raw_recs_df.join(watched_items_df, on="userIndex", how="left") \
            .withColumn("watched_items", F.coalesce(F.col("watched_items"), F.array().cast("array<int>"))) \
            .withColumn(
                "novel_recs_structs", 
                F.expr("filter(recommendations, x -> not array_contains(watched_items, x.itemIndex))")
            ) \
            .withColumn("top_k_structs", F.expr(f"slice(novel_recs_structs, 1, {k_novel})")) \
            .select("userIndex", F.col("top_k_structs.itemIndex").alias("predicted_items"))
            
        return novel_recs_df

    def train_ALS(self, als_params, print_metrics=True):
        train_data = self.data_prep.indexed_train
        k_novel = als_params.get('k', 15)
        
        print("Training ALS Model...")
        als = ALS(
            userCol="userIndex", 
            itemCol="itemIndex", 
            ratingCol="confidence", 
            implicitPrefs=als_params.get("implicitPrefs", True), 
            maxIter=als_params["maxIter"], 
            coldStartStrategy=als_params["coldStartStrategy"],
            rank=als_params["rank"], 
            alpha=als_params["alpha"],
            regParam=als_params["regParam"], 
            
        )

        self.als_model = als.fit(train_data)

        # 1. Generate 50 raw recs for Coverage
        print("Generating 50 raw recommendations for all users...")
        self.als_raw_50 = self.als_model.recommendForAllUsers(50).cache()

        # 2. Generate 15 novel recs for Recall/Precision
        self.als_novel_15 = self._generate_novel_recommendations(self.als_raw_50, k_novel).cache()

        metrics = None
        if print_metrics:
            metrics = self.evaluate_model(k_novel=k_novel)

        return metrics

    def save_model_checkpoint(self, checkpoint_folder="als_checkpoint"):
        """
        Saves the Model, the 50 raw recommendations, and the 15 novel recommendations.
        (Lookups should be saved/handled in DataPreparation class).
        """
        base_path = f"{self.config['temp_path']}/{checkpoint_folder}"
        print(f"Saving ALL ALS artifacts to {base_path}...")
        
        if self.als_model:
            self.als_model.write().overwrite().save(f"{base_path}/als_model")
        if self.als_raw_50:
            self.als_raw_50.write.mode("overwrite").parquet(f"{base_path}/als_raw_50")
        if self.als_novel_15:
            self.als_novel_15.write.mode("overwrite").parquet(f"{base_path}/als_novel_15")
            
        print("Model checkpoint successfully saved!")

    def load_model_checkpoint(self, checkpoint_folder="als_checkpoint"):
        """
        Loads the pre-computed models and recommendations directly from storage.
        """
        base_path = f"{self.config['temp_path']}/{checkpoint_folder}"
        print(f"Loading ALS artifacts from: {base_path}...")
        
        try:
            self.als_model = ALSModel.load(f"{base_path}/als_model")
            self.als_raw_50 = self.spark.read.parquet(f"{base_path}/als_raw_50").cache()
            self.als_novel_15 = self.spark.read.parquet(f"{base_path}/als_novel_15").cache()
            print("Model checkpoint loaded successfully! Ready for inference.")
        except Exception as e:
            print(f"Critical Error loading model checkpoint: {e}")
            raise RuntimeError(f"Failed to load from {base_path}. Ensure you trained and saved the model first.")

    def evaluate_model(self, k_novel=15):
        """Evaluates Coverage using the raw 50 recs, and Recall using the novel 15 recs."""
        if not self.als_raw_50 or not self.als_novel_15:
            raise ValueError("Predictions missing. Please train or load the model first.")

        print("\n" + "="*50)
        print("EVALUATING MODEL METRICS")
        print("="*50)

        # ---------------------------------------------------------
        # METRIC 1: COVERAGE (@50 raw recommendations)
        # ---------------------------------------------------------
        # Explode array of structs -> get the itemIndex
        exploded_recs = self.als_raw_50.select(
            "userIndex", 
            F.explode("recommendations").alias("rec")
        ).select("userIndex", F.col("rec.itemIndex").alias("itemIndex"))

        item_counts = exploded_recs.groupBy("itemIndex").agg(F.count("userIndex").alias("times_recommended"))

        final_counts_df = self.data_prep.item_lookup.join(item_counts, on="itemIndex", how="left") \
            .fillna({"times_recommended": 0})

        total_items = final_counts_df.count()
        covered_items = final_counts_df.filter(F.col("times_recommended") > 0).count()
        
        coverage = covered_items / total_items if total_items > 0 else 0.0

        # ---------------------------------------------------------
        # SANITY STEP: Filter Test users to ensure they exist in Train
        # ---------------------------------------------------------
        ground_truth = self.data_prep.ground_data
        train_users = self.data_prep.indexed_train.select("userIndex").distinct()
        
        # Inner join ensures we only evaluate users who were in both sets
        valid_ground_truth = ground_truth.join(train_users, on="userIndex", how="inner")

        # ---------------------------------------------------------
        # METRIC 2: RECALL / PRECISION (@15 novel recommendations)
        # ---------------------------------------------------------
        joined_data = self.als_novel_15.join(valid_ground_truth, "userIndex").dropna()
        
        eval_df = joined_data \
            .withColumn("hits", F.size(F.array_intersect(F.col("predicted_items"), F.col("actual_items")))) \
            .withColumn("actual_count", F.size(F.col("actual_items"))) \
            .withColumn("recall", F.col("hits") / F.col("actual_count"))
            
        avg_recall = eval_df.select(F.mean("recall")).collect()[0][0] or 0.0
        
        rdd_data = joined_data.select("predicted_items", "actual_items").rdd.map(tuple)
        metrics = RankingMetrics(rdd_data)

        Model_Metrics = {
            "coverage": coverage,
            "avg_recall": avg_recall,
            "precision_k": metrics.precisionAt(k_novel),
            "map": metrics.meanAveragePrecision
        }
        print(f"Catalog Coverage (@50): {Model_Metrics['coverage']:.4f}  ({covered_items} / {total_items} items recommended)")

        print(f"\n[Ranking Performance]")
        print(f"Users Evaluated (Train/Test intersection): {joined_data.count()}")
        print(f"Precision@{k_novel}: {Model_Metrics['precision_k']:.4f}")
        print(f"Recall@{k_novel}:    {Model_Metrics['avg_recall']:.4f}")
        print(f"MAP:             {Model_Metrics['map']:.4f}")
        print("="*50 + "\n")

        return Model_Metrics

    # ==========================================
    # INFERENCE METHODS 
    # ==========================================
    def _get_titles_for_indices(self, item_indices):
        if self.data_prep.item_lookup is None or self.data_prep.metadata_df is None:
            raise ValueError("Item lookup or metadata table not found in data_prep.")
        
        indices_df = self.spark.createDataFrame([(int(idx),) for idx in item_indices], ["itemIndex"])
        
        titles_df = indices_df.join(self.data_prep.item_lookup, on="itemIndex", how="left") \
            .join(self.data_prep.metadata_df, on="item_id", how="left") \
            .select("title", "item_id", "Genres")
            
        return titles_df

    def get_recommendations_userId(self, userId):
        if self.als_novel_15 is None:
            raise ValueError("ALS novel predictions not available. Train or load checkpoint first.")
        
        if self.data_prep.combined_train_df is not None and self.data_prep.metadata_df is not None:
            hist = self.data_prep.combined_train_df.filter(F.col("userId") == userId) \
                .join(self.data_prep.metadata_df, on="item_id", how="left") \
                .select("title", "item_id", "Genres")
                
            print(f"\nWatch/Click History for userId {userId}:")
            if hist.count() > 0:
                print("Watch History Count: ", hist.count())
                hist.show(truncate=False)
            else:
                print("  - [No title metadata found for history]")
        else:
            print("\n[Warning: combined_train_df or metadata_df missing. Cannot fetch history.]")
        
        user_index_row = self.data_prep.user_lookup.filter(F.col("userId") == userId).select("userIndex").collect()
        
        if not user_index_row:
            print(f"User ID {userId} not found in user lookup.")
            return []
            
        target_index = user_index_row[0]["userIndex"]
        recs = self.als_novel_15.filter(F.col("userIndex") == target_index).select("predicted_items").collect()

        if recs:
            reco_df = self._get_titles_for_indices(recs[0]["predicted_items"])
            print(f"\nTop Novel Recommendations for userId {userId}:")
            reco_df.show(truncate=False) 
            return reco_df
        else:
            print(f"No recommendations generated by ALS for user index: {target_index}")
            return []

    def get_recommendations_random_user(self, min_content_threshold=1):
        if self.data_prep is None or self.data_prep.combined_train_df is None:
            raise ValueError("Data preparation object or combined_train_df is missing.")

        train_data = self.data_prep.combined_train_df

        valid_users_df = train_data.groupBy("userId") \
            .agg(F.count("item_id").alias("distinct_content_count")) \
            .filter(F.col("distinct_content_count") >= min_content_threshold)

        random_row = valid_users_df.orderBy(F.rand()).first()

        if random_row is None:
            print(f"No users found matching the threshold of {min_content_threshold}.")
            return []

        random_userId = random_row["userId"]
        
        print(f"\n" + "="*50)
        print(f"Randomly Selected User: {random_userId}")
        print(f"User's Historical Item Count: {random_row['distinct_content_count']}")
        print("="*50)

        return self.get_recommendations_userId(random_userId)